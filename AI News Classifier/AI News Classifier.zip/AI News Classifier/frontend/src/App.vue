<template>
  <router-view></router-view>
</template>

<script>
import ViewBase from './ViewBase.vue'




export default {
  name: 'App',
  data() {
    return {
      
    }
  },

  components: {
    ViewBase
  },
  methods : {
  }
}
</script>
<style>


</style>

