The frontend and the backend are separated.

To run the frontend, first open your terminal in the frontend directory and run: 'npm i' to install the node modules
Then run: 'npm run serve'

The home page is serverd at:
localhost/home


To run the backend, 
simply run the app.py file

The database is named as 'everything'

preds_model stores the BERT model and transformer

Thank you